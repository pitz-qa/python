print("mylib.py:", __name__)
