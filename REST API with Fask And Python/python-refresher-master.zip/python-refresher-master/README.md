# Python Refresher

This repository contains our Python Refresher or Reference code, ordered by lecture.

Feel free to bookmark or download this code to come back to it at a later date!