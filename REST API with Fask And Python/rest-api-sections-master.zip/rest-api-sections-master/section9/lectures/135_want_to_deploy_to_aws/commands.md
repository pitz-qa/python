## Deploy to AWS
If deploying on AWS, after installing Ubuntu 16.04, make sure to install libpcre3 and libpcre3-dev by running the following commands:

```bash
sudo apt-get install libpcre3 libpcre3-dev 
pip install uwsgi -I --no-cache-dir 
```
